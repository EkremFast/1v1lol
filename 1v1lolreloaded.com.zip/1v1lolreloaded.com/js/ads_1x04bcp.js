// AdinPlay ads for the 4.46 WebGL game page (/index.html). Tag: UBG/1v1lolreloaded.com (approved 2026-11-12).
// Spec and tag internals: test-446/_kb/ad_integration_adinplay.md.
//
// The game page is the same document on our landing and inside every third-party embed (its host is always
// 1v1lolreloaded.com), so the ads below run in our frame on every embed: the Playtika model.
// On any other host (onecloudcdn.site, localhost) this file stays passive and bridges.js keeps its instant stubs.
// serve.js webAdsFor() mirrors that host rule: only there does ServerUser.Premium.AdsDisabled go out false, which is
// what makes the client reserve the left banner strip, call showAds()/hideAds() and offer its rewarded buttons.
//
// What runs here (owner spec 2026-11-12):
//  1. Preroll video as soon as the page loads (PREROLL below; after Play on our landing;
//     when an embed loads the frame), fullscreen.
//     The game starts loading only after it, as in AdinPlay's own sample (content starts in AIP_COMPLETE): this file
//     sits between WebGL.loader.js and boot.js and holds createUnityInstance until the preroll is over, or for at
//     most 5 s if the tag never gets ready (ad blocker, slow network). Owner, 2026-11-12: ad and loading at once
//     was a collision.
//  2. Banner column at the left edge while the client wants banners: showAds() in the main menu and on pause,
//     hideAds() at match start and on unpause. Owner, 2026-11-15: the 300x600 (1v1lolreloaded.com_300x600) is the
//     main slot, with the 300x250 (1v1lolreloaded-com_300x250) under it once both fit (fullscreen), and the 300x250
//     alone in a frame too low for the 300x600. Slots switch when the height changes (fullscreen on/off) and are
//     requested as in AdinPlay's sample page (see "Page elements" for why). The tag reloads a visible slot itself
//     every 30 s.
//  3. Rewarded video for every rewarded button the client has (guest Daily Skins, the extra Daily Spin, Double XP,
//     Mystery Skin, Zombies respawn): they all reach page showWebRVAd() → aipAds.showRewarded().
// Not here: the pre-match interstitial. bridges.js requestNewAd() stays an instant stub because its
// OnWebInterstitialEnded is what releases matchmaking.
(function () {
  'use strict';

  var TAG_ID = 'UBG/1v1lolreloaded.com';
  var UNIT_300X250 = '1v1lolreloaded-com_300x250';
  // "double mpu", placement 13133; takes 300x600, 160x600, 300x250, 120x600, 120x240 creatives. Note the dot in
  // the name (the 300x250 unit has a dash). The tag does not pick sizes by the node's height, so its slot is 600 px.
  var UNIT_300X600 = '1v1lolreloaded.com_300x600';

  var host = String(location.hostname || '').toLowerCase();
  var LIVE = host === '1v1lolreloaded.com' || host === 'www.1v1lolreloaded.com';
  // Preroll on page load. Off 2026-11-14..15 while the dashboard showed 0; back on 2026-11-15 (owner) after a
  // real-browser check of the preroll inside the landing frame (KB). false = no Unity start gate, the game starts
  // loading at once as on other hosts; banners and rewarded do not depend on it.
  var PREROLL = true;
  // Layout check without the tag (localhost): localStorage.AIP_DEV = '1' draws the column with empty slots.
  var DEV_LAYOUT = false;
  try { DEV_LAYOUT = !LIVE && localStorage.getItem('AIP_DEV') === '1'; } catch (e) {}
  // Same test as Unity's WebGL loader (SystemInfo.mobile). The client reserves the banner strip only when
  // !IsMobile, so the column must follow exactly the same rule or it would cover the game UI on phones.
  var MOBILE = /Mobile|Android|iP(ad|hone)/.test(navigator.appVersion || '');

  var log = function () {};
  try {
    if (localStorage.getItem('AD_DIAG') === '1') {
      log = function () {
        var a = ['%c[aip]', 'color:#0bf'];
        for (var i = 0; i < arguments.length; i++) a.push(arguments[i]);
        console.warn.apply(console, a);   // warn: the public build silences console.log
      };
    }
  } catch (e) {}

  function once(fn) {
    var done = false;
    return function () { if (done) return; done = true; return fn.apply(this, arguments); };
  }

  // ── Game audio off while a video ad plays ─────────────────────────────────────────────────────────────────
  // Unity creates its AudioContext inside the loader; track every context created from now on so a preroll or a
  // rewarded ad can suspend them. A context created while an ad is up starts suspended.
  var audioContexts = [];
  var audioHolds = 0;
  function suspendCtx(ctx) {
    try { if (ctx.state === 'running') { ctx.__aipSuspended = true; ctx.suspend(); } } catch (e) {}
  }
  ['AudioContext', 'webkitAudioContext'].forEach(function (name) {
    var Orig = window[name];
    if (typeof Orig !== 'function' || typeof Reflect === 'undefined') return;
    var Tracked = function () {
      var ctx = Reflect.construct(Orig, arguments, Orig);
      audioContexts.push(ctx);
      if (audioHolds > 0) setTimeout(function () { suspendCtx(ctx); }, 0);
      return ctx;
    };
    Tracked.prototype = Orig.prototype;
    window[name] = Tracked;
  });
  function muteGame() {
    audioHolds++;
    audioContexts.forEach(suspendCtx);
  }
  function unmuteGame() {
    if (audioHolds > 0) audioHolds--;
    if (audioHolds > 0) return;
    audioContexts.forEach(function (ctx) {
      try { if (ctx.__aipSuspended) { ctx.__aipSuspended = false; ctx.resume(); } } catch (e) {}
    });
  }

  // ── An ad never changes the fullscreen state ──────────────────────────────────────────────────────────────
  // The tag frames ad creatives with allow="fullscreen" and its video player has viewModeFullscreen, so a creative
  // can take the browser fullscreen on its own: a rewarded ad turned a windowed game fullscreen (owner, 2026-11-12:
  // "если игра в окне, то rewarded тоже должен быть в окне"). While an ad is up, a page that was windowed when it
  // started is put back to windowed on every fullscreenchange; a fullscreen page is left alone.
  var windowedDuringAd = false;
  function fullscreenEl() { return document.fullscreenElement || document.webkitFullscreenElement || null; }
  function leaveFullscreen() {
    try { (document.exitFullscreen || document.webkitExitFullscreen).call(document); } catch (e) {}
  }
  function onFullscreenChange() {
    if (windowedDuringAd && fullscreenEl()) { log('ad went fullscreen -> back to windowed'); leaveFullscreen(); }
  }
  document.addEventListener('fullscreenchange', onFullscreenChange);
  document.addEventListener('webkitfullscreenchange', onFullscreenChange);
  // Refuse the request at the source so the browser never flips at all (undoing it afterwards flickers; owner,
  // 2026-11-12). Fullscreen needs a fresh user click, and the one at hand is the player's click on the reward button
  // in THIS window, so the request comes from code running here: the ad libraries the tag loads into this page.
  // While an ad is up on a windowed page, requestFullscreen from this window is refused. Installed before any ad
  // library loads, so a library that keeps a reference to the method gets this wrapper too. The fullscreenchange
  // fallback above stays for a request from anywhere else.
  ['requestFullscreen', 'webkitRequestFullscreen', 'webkitRequestFullScreen', 'mozRequestFullScreen', 'msRequestFullscreen']
    .forEach(function (name) {
      var proto = window.Element && window.Element.prototype;
      var orig = proto && proto[name];
      if (typeof orig !== 'function') return;
      proto[name] = function () {
        if (windowedDuringAd) {
          log('ad asked for fullscreen (' + name + ') -> refused');
          return name === 'requestFullscreen' ? Promise.reject(new TypeError('Fullscreen is off while an ad plays')) : undefined;
        }
        return orig.apply(this, arguments);
      };
    });

  // Start/end of a video ad (preroll or rewarded): game audio off, fullscreen state kept.
  function adStarted() {
    muteGame();
    windowedDuringAd = !fullscreenEl();
  }
  function adEnded() {
    unmuteGame();
    if (windowedDuringAd && fullscreenEl()) leaveFullscreen();
    windowedDuringAd = false;
  }

  // ── Page elements ─────────────────────────────────────────────────────────────────────────────────────────
  // Column = the strip the client frees on the left (SafeArea, 300 * Screen.dpi / 100 px). Like Playtika's .ads
  // column it sits over the canvas (z-index 40) and spaces the slots evenly. Its edges stay free where something
  // else sits there:
  //  - top: the tag's "Privacy settings" link (EU consent, buttonPosition top-left). The tag creates it in its ROOT
  //    document, so it is in this page when the page is top-level or in a third-party embed, and on the landing
  //    page (not here) when our own landing frames the game.
  //  - bottom: the "Powered by" badge (index.html, bottom-left), shown only in third-party embeds.
  // Without the padding a 300x600 fits in our landing's usual frame (16:9 next to a 26rem rail, about 520-670 px).
  var FRAME = (function () {
    if (window.parent === window) return 'top';
    try { return window.parent.location.hostname === location.hostname ? 'landing' : 'embed'; } catch (e) { return 'embed'; }
  })();
  var PAD_TOP = FRAME === 'landing' ? 8 : 44;
  var PAD_BOTTOM = FRAME === 'embed' ? 52 : 8;
  var SLOT_GAP = 16;
  var CSS = ''
    + '#aip-ads{position:fixed;left:0;top:0;bottom:0;width:300px;z-index:40;display:none;flex-direction:column;'
    +   'justify-content:space-evenly;padding:' + PAD_TOP + 'px 0 ' + PAD_BOTTOM + 'px;pointer-events:none}'
    + '#aip-ads.aip-on{display:flex}'
    + '#aip-ads .aip-slot{width:300px;height:250px;flex:none;overflow:hidden;background:rgba(0,0,0,.4);pointer-events:auto}'
    + '#aip-ads .aip-slot.aip-tall{height:600px}'
    + '#aip-ads .aip-slot.aip-hidden{display:none}'
    + '#aip-ads.aip-dev .aip-slot{outline:1px dashed #0bf;color:#0bf;font:12px/250px monospace;text-align:center}'
    + '#aip-videoad{position:fixed;inset:0;z-index:100000;display:none;align-items:center;justify-content:center;background:#000}'
    // The consent link only while the column is up: never over the game UI in a match.
    + 'body:not(.aip-banners-on) #cmpPersistentLink{display:none!important}';

  var styleAdded = false;
  function addStyle() {
    if (styleAdded) return;
    styleAdded = true;
    var s = document.createElement('style');
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  // Each slot is a div whose id is the unit name, requested with display('<unit>'), exactly as in AdinPlay's sample
  // page. Not display({adUnitName, nodeProvider: {selector}}): the tag runs that selector through querySelectorAll
  // on its ROOT window's document, i.e. the topmost same-origin window. On our landing that is the page around the
  // game iframe, so the selector never found the column and no banner was ever requested there (found 2026-11-15;
  // it only worked on /index.html opened directly and in cross-origin embeds). For an id the tag uses its own
  // document. One id holds one unit, so the column has at most one 300x600 and one 300x250.
  var SLOT_ORDER = [UNIT_300X600, UNIT_300X250];   // top to bottom
  var column = null;
  var slotNodes = {};
  function getColumn() {
    if (column) return column;
    addStyle();
    column = document.createElement('div');
    column.id = 'aip-ads';
    if (DEV_LAYOUT) column.className = 'aip-dev';
    SLOT_ORDER.forEach(function (unit) {
      var n = document.createElement('div');
      n.id = unit;
      n.className = 'aip-slot aip-hidden' + (unit === UNIT_300X600 ? ' aip-tall' : '');
      if (DEV_LAYOUT) n.textContent = unit === UNIT_300X600 ? '300x600' : '300x250';
      column.appendChild(n);
      slotNodes[unit] = n;
    });
    document.body.appendChild(column);
    return column;
  }

  // Slots for a frame height: the 300x600, plus the 300x250 under it once both fit; the 300x250 alone when the
  // 300x600 does not fit; none when not even the 300x250 fits (small third-party embeds): a cut-off ad is worse
  // than an empty strip.
  function slotsFor(h) {
    var room = h - PAD_TOP - PAD_BOTTOM;
    if (room >= 600 + SLOT_GAP + 250) return [UNIT_300X600, UNIT_300X250];
    if (room >= 600) return [UNIT_300X600];
    if (room >= 250) return [UNIT_300X250];
    return [];
  }
  function slotShown(unit) { return !!slotNodes[unit] && !slotNodes[unit].classList.contains('aip-hidden'); }

  // Shows and hides slots for the current height (a hidden slot is not reloaded by the tag); returns the units that
  // just became visible.
  function fitSlots() {
    getColumn();
    var want = slotsFor(window.innerHeight);
    var appeared = [];
    var changed = false;
    SLOT_ORDER.forEach(function (unit) {
      var on = want.indexOf(unit) >= 0;
      if (on === slotShown(unit)) return;
      changed = true;
      if (on) { slotNodes[unit].classList.remove('aip-hidden'); appeared.push(unit); }
      else slotNodes[unit].classList.add('aip-hidden');
    });
    if (changed) log('slots:', want.join(' + '), 'at height', window.innerHeight, '(' + FRAME + ')');
    return appeared;
  }

  // First display() of a unit creates its placement; later calls reload it (the tag skips a reload within 5 s of
  // the last one).
  function requestSlot(unit) {
    window.aiptag.cmd.display.push(function () { window.aipDisplayTag.display(unit); });
  }

  // Fullscreen on/off and window resizes while the column is up: switch slots, request the ones that appeared.
  var resizeTimer = null;
  window.addEventListener('resize', function () {
    if (!column || !column.classList.contains('aip-on')) return;
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      if (!column.classList.contains('aip-on')) return;
      var appeared = fitSlots();
      if (LIVE) appeared.forEach(requestSlot);
    }, 400);
  });

  var videoEl = null;
  function getVideoEl() {
    if (videoEl) return videoEl;
    addStyle();
    videoEl = document.createElement('div');
    videoEl.id = 'aip-videoad';
    document.body.appendChild(videoEl);
    return videoEl;
  }

  // ── Unity start gate ──────────────────────────────────────────────────────────────────────────────────────
  // boot.js calls the global createUnityInstance right after this file; the wrapper returns the same promise
  // shape, only later. Opened by the end of the preroll, or by the 5 s "tag not ready" timeout, which also
  // cancels the preroll so it can never pop up over a loading game.
  // index.html hides the loading screen from the first paint (html.aip-wait); opening the gate shows it again.
  var gateOpen = !(LIVE && PREROLL);
  var gateWaiters = [];
  function showLoadingScreen() { document.documentElement.classList.remove('aip-wait'); }
  function openGate(why) {
    if (gateOpen) return;
    gateOpen = true;
    log('unity start:', why);
    showLoadingScreen();
    gateWaiters.splice(0).forEach(function (f) { f(); });
  }
  if (LIVE && PREROLL && typeof window.createUnityInstance === 'function') {
    var realCreateUnityInstance = window.createUnityInstance;
    window.createUnityInstance = function () {
      var self = this, args = arguments;
      return new Promise(function (resolve) { if (gateOpen) resolve(); else gateWaiters.push(resolve); })
        .then(function () { return realCreateUnityInstance.apply(self, args); });
    };
  } else {
    gateOpen = true;
    showLoadingScreen();
  }

  // ── Tag and player ────────────────────────────────────────────────────────────────────────────────────────
  var playerReady = false;
  var preroll = null;    // { done(state) } while the preroll is up
  var rewarded = null;   // { done(state) } while a rewarded ad is requested or showing

  if (LIVE && PREROLL) setTimeout(function () { if (!playerReady) openGate('tag-not-ready'); }, 5000);

  function startPreroll() {
    if (!playerReady || !document.body) return;
    if (gateOpen) { log('preroll skipped: game already loading'); return; }
    var el = getVideoEl();
    var safety = null;
    preroll = {
      done: once(function (state) {
        log('preroll done:', state);
        clearTimeout(safety);
        preroll = null;
        el.style.display = 'none';   // the tag also hides PREROLL_ELEM itself
        adEnded();
        openGate('preroll ' + state);
      }),
    };
    el.style.display = 'flex';
    adStarted();
    // Backstop if the tag never reports back (it has its own timeouts; a long video ad is ~30 s). The game waits
    // for this, so keep it short.
    safety = setTimeout(function () { if (preroll) preroll.done('safety-timeout'); }, 45000);
    try { window.aiptag.adplayer.startPreRoll(); } catch (e) { preroll.done('error'); }
  }

  if (LIVE) {
    window.aiptag = window.aiptag || { cmd: [] };
    window.aiptag.cmd = window.aiptag.cmd || [];
    window.aiptag.cmd.display = window.aiptag.cmd.display || [];
    window.aiptag.cmd.player = window.aiptag.cmd.player || [];
    // EU consent (TCF) is the tag's own CMP; its persistent link is shown only where consent applies.
    window.aiptag.cmp = { button: true, buttonText: 'Privacy settings', buttonPosition: 'top-left' };

    window.aiptag.cmd.player.push(function () {
      window.aiptag.adplayer = new window.aipPlayer({
        AD_WIDTH: 960,
        AD_HEIGHT: 540,
        // fullscreen: the tag draws its own black layer over the whole page. NOT 'default': that renderer forces
        // PREROLL_ELEM to 960x540 inline, so the ad sat in the top-left corner over the loading screen (2026-11-12).
        AD_DISPLAY: 'fullscreen',
        LOADING_TEXT: 'loading advertisement',
        PREROLL_ELEM: function () { return getVideoEl(); },
        AIP_COMPLETE: function (state) { if (preroll) preroll.done(state); },
        AIP_REWARDEDGRANTED: function () { if (rewarded) rewarded.done('granted'); },
        AIP_REWARDEDNOTGRANTED: function (state) { if (rewarded) rewarded.done(state || 'not-granted'); },
      });
      playerReady = true;
      log('player ready');
      if (!PREROLL) return;
      if (document.body) startPreroll();
      else document.addEventListener('DOMContentLoaded', startPreroll);
    });

    var tag = document.createElement('script');
    tag.async = true;
    tag.onerror = function () { openGate('tag-blocked'); };   // ad blocker or network: start the game at once
    tag.src = 'https://api.adinplay.com/libs/aiptag/pub/' + TAG_ID + '/tag.min.js';
    (document.head || document.documentElement).appendChild(tag);
  }

  // ── API for bridges.js ────────────────────────────────────────────────────────────────────────────────────
  var bannersRequested = false;

  window.aipAds = {
    // page showAds(): main menu, pause.
    showBanners: function () {
      if ((!LIVE && !DEV_LAYOUT) || MOBILE || !document.body) return;
      getColumn().classList.add('aip-on');
      fitSlots();
      document.body.classList.add('aip-banners-on');
      if (!LIVE) return;
      // A player back from a match gets fresh banners (reload of the existing placements).
      SLOT_ORDER.forEach(function (unit) { if (slotShown(unit)) requestSlot(unit); });
      if (!bannersRequested) { bannersRequested = true; log('banners requested'); }
    },

    // page hideAds(): match start, unpause. A hidden slot is never reloaded (the tag needs it visible).
    hideBanners: function () {
      if (column) column.classList.remove('aip-on');
      if (document.body) document.body.classList.remove('aip-banners-on');
    },

    // True when showRewarded() will request a real ad; false → bridges.js keeps its instant path.
    rewardedAvailable: function () { return LIVE && playerReady && !rewarded && !preroll; },

    // page showWebRVAd(). onDone(state) fires exactly once on ANY outcome: granted, closed, empty, timeout,
    // error. 4.46 has no ad-failure callback, so the caller grants on every outcome (the soft gate the owner
    // approved on 2026-06-21); real views still earn.
    showRewarded: function (onDone) {
      var safety = null;
      rewarded = {
        done: once(function (state) {
          log('rewarded done:', state);
          clearTimeout(safety);
          rewarded = null;
          adEnded();
          try { onDone(state); } catch (e) {}
        }),
      };
      adStarted();
      // Backstop if neither callback ever comes; the tag itself gives up after 5 s without a ready ad.
      safety = setTimeout(function () { if (rewarded) rewarded.done('safety-timeout'); }, 150000);
      try {
        // showLoading: false (owner, 2026-11-15). With true the tag puts a black full-page "loading" layer into its
        // ROOT document, i.e. over the whole landing even in windowed play, and with no ad it only flashes for a
        // second before the reward. The ad itself is a GPT rewarded overlay and is shown either way.
        window.aiptag.adplayer.startRewardedAd({ preload: false, showLoading: false });
      } catch (e) {
        rewarded.done('error');
      }
    },
  };
})();
